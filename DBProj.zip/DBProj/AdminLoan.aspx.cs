﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;
using System.Collections.Specialized;

namespace DBProj
{
    public partial class AdminLoan : System.Web.UI.Page
    {
        private const int PageSize = 10;
        private int CurrentPage = 1;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Loans ORDER BY LoanID ASC OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY", con);
                cmd.Parameters.AddWithValue("@Offset", (CurrentPage - 1) * PageSize);
                cmd.Parameters.AddWithValue("@PageSize", PageSize);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                GridView1.DataSource = null;
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void btnPrev_Click(object sender, EventArgs e)
        {
            CurrentPage--;
            if (CurrentPage < 1)
                CurrentPage = 1;
            BindGrid();

        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            CurrentPage++;
            BindGrid();
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "SeeMore")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument); // Get the index of the row where the button was clicked
                GridViewRow firstRow = GridView1.Rows[rowIndex];
                TableCell firstCell = firstRow.Cells[0];
                int cid = Convert.ToInt32(firstCell.Text);
                try
                {
                    if (rowIndex >= 0 && rowIndex < GridView1.Rows.Count)
                    {
                        DataTable dt4 = new DataTable();
                        GridView1.DataSource = dt4;
                        GridView1.DataBind();

                        string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {

                            SqlCommand cmd = new SqlCommand("DELETE FROM Loans WHERE LoanID = @LoanID", conn);
                            cmd.Parameters.AddWithValue("@LoanID", cid);
                            conn.Open();
                            cmd.ExecuteNonQuery();

                            SqlCommand cmd2 = new SqlCommand("SELECT * FROM Loans ORDER BY LoanID ASC OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY", conn);
                            SqlDataReader reader = cmd2.ExecuteReader();

                            GridView1.DataSource = reader;
                            GridView1.DataBind();

                            reader.Close();
                        }
                    }
                    else
                    {
                        // Handle invalid rowIndex (e.g., log error, display message to user)
                    }
                }
                catch (Exception ex)
                {


                }


            }
        }
    }
}
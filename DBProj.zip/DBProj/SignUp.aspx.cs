﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;

namespace DBProj
{
    public partial class SignUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void log_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                    SqlCommand cmd2 = new SqlCommand("InsertIntoSignUp", conn);

                    try
                    {
                            cmd2.CommandType = CommandType.StoredProcedure; 
                            cmd2.Parameters.AddWithValue("@Fullname", name.Text.Trim());
                            cmd2.Parameters.AddWithValue("@CNIC", cnic.Text.Trim());
                            cmd2.Parameters.AddWithValue("@Username", username.Text.Trim());
                            cmd2.Parameters.AddWithValue("@Pin", Pin.Text.Trim());
                            cmd2.Parameters.AddWithValue("@AccountType", ddlOptions.SelectedValue); 
                            SqlParameter outputParam = new SqlParameter("@output", SqlDbType.VarChar, 100);
                            outputParam.Direction = ParameterDirection.Output;
                            cmd2.Parameters.Add(outputParam);
                            conn.Open();
                            cmd2.ExecuteNonQuery();

                            string outputMessage = cmd2.Parameters["@output"].Value.ToString();
                            conn.Close();

                            lblErrorMessage.Text = outputMessage;
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = System.Drawing.Color.Green;
                    }
                    catch (Exception ex)
                    {
                        lblErrorMessage.Text = "An error occurred: " + ex.Message;
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                    }

            }
        }
    }
}
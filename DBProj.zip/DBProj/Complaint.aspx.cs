﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;

namespace DBProj
{
    public partial class Complaints : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Connection string from web.config
                string connectionString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("SELECT TOP 10 Complain FROM Complaints ORDER BY ComplainID DESC", conn);


                    cmd.Parameters.AddWithValue("@UserID", Login.Login_ID);

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    GridView1.DataSource = reader;
                    GridView1.DataBind();

                    reader.Close();
                }
            }
        }

        protected void log_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd2 = new SqlCommand("InsertIntoComplaints", conn);

                try
                {
                    if (Complaint.Text.Trim() != "")
                    {
                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Parameters.AddWithValue("@UserID", Login.Login_ID);
                        cmd2.Parameters.AddWithValue("@Complain", Complaint.Text.Trim());
                        SqlParameter outputParam = new SqlParameter("@output", SqlDbType.VarChar, 140);
                        outputParam.Direction = ParameterDirection.Output;
                        cmd2.Parameters.Add(outputParam);
                        conn.Open();
                        cmd2.ExecuteNonQuery();

                        string outputMessage = cmd2.Parameters["@output"].Value.ToString();
                        conn.Close();


                        lblErrorMessage.Text = outputMessage;
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = System.Drawing.Color.Green;
                    }
                    SqlCommand cmd = new SqlCommand("SELECT TOP 10 Complain FROM Complaints ORDER BY ComplainID DESC", conn);


                    cmd.Parameters.AddWithValue("@UserID", Login.Login_ID);

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    GridView1.DataSource = reader;
                    GridView1.DataBind();

                    reader.Close();

                }
                catch (Exception ex)
                {
                    lblErrorMessage.Text = "An error occurred: " + ex.Message;
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;
using System.Collections.Specialized;

namespace DBProj
{
    public partial class Details : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT UserID, FullName, CNIC, Balance, AccountType, AccountStatus, Heirs FROM Accounts WHERE UserID = @UserID", conn);
                cmd.Parameters.AddWithValue("@UserID", Login.Login_ID);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                GridView1.DataSource = dt;
                GridView1.DataBind();
                reader.Close();

                SqlCommand cmd2 = new SqlCommand("SELECT CardID, CardType, CreditLimit FROM Cards WHERE UserID = @UserID", conn);
                cmd2.Parameters.AddWithValue("@UserID", Login.Login_ID);
                SqlDataReader reader1 = cmd2.ExecuteReader();
                DataTable dt1 = new DataTable();
                dt1.Load(reader1);
                GridView2.DataSource = dt1;
                GridView2.DataBind();
                reader1.Close();

                SqlCommand cmd3 = new SqlCommand("SELECT BillID, Date, TransactionAmount, ReceiverID FROM Bills WHERE UserID = @UserID", conn);
                cmd3.Parameters.AddWithValue("@UserID", Login.Login_ID);
                SqlDataReader reader2 = cmd3.ExecuteReader();
                DataTable dt2 = new DataTable();
                dt2.Load(reader2);
                GridView3.DataSource = dt2;
                GridView3.DataBind();
                reader2.Close();
            }
        }
        protected void logout(object sender, EventArgs e)
        {
            Login.Login_ID = 0;
            Response.Redirect("Login.aspx");
        }

        protected void log_Click(object sender, EventArgs e)
        {

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;
using System.Drawing.Printing;
using System.Drawing;

namespace DBProj
{
    public partial class AdminComplaints : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Connection string from web.config
                string connectionString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("SELECT TOP 10 ComplainID, Complain FROM Complaints ORDER BY ComplainID DESC", conn);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    GridView1.DataSource = reader;
                    GridView1.DataBind();

                    reader.Close();
                }
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "SeeMore")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument); // Get the index of the row where the button was clicked
                GridViewRow firstRow = GridView1.Rows[rowIndex];
                TableCell firstCell = firstRow.Cells[0];
                int cid = Convert.ToInt32(firstCell.Text);
                try
                {
                    if (rowIndex >= 0 && rowIndex < GridView1.Rows.Count)
                    {
                        DataTable dt4 = new DataTable();
                        GridView1.DataSource = dt4;
                        GridView1.DataBind();

                        string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {

                            SqlCommand cmd = new SqlCommand("DELETE FROM Complaints WHERE ComplainID = @ComplainID", conn);
                            cmd.Parameters.AddWithValue("@ComplainID", cid);
                            conn.Open();
                            cmd.ExecuteNonQuery();

                            SqlCommand cmd2 = new SqlCommand("SELECT TOP 10 ComplainID, Complain FROM Complaints ORDER BY ComplainID DESC", conn);
                            SqlDataReader reader = cmd2.ExecuteReader();

                            GridView1.DataSource = reader;
                            GridView1.DataBind();

                            reader.Close();
                        }
                    }
                    else
                    {
                        // Handle invalid rowIndex (e.g., log error, display message to user)
                    }
                }
                catch (Exception ex)
                {


                }


            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;
using System.Collections.Specialized;

namespace DBProj
{
    public partial class AdminTran : System.Web.UI.Page
    {
        private const int PageSize = 10;
        private int CurrentPage = 1;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Transactions ORDER BY TransactionID ASC OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY", con);
                cmd.Parameters.AddWithValue("@Offset", (CurrentPage - 1) * PageSize);
                cmd.Parameters.AddWithValue("@PageSize", PageSize);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                GridView1.DataSource = null;
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void btnPrev_Click(object sender, EventArgs e)
        {
            CurrentPage--;
            if (CurrentPage < 1)
                CurrentPage = 1;
            BindGrid();

        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            CurrentPage++;
            BindGrid();
        }
    }
}
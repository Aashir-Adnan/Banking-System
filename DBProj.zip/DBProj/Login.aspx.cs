﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DBProj
{
    public partial class Login : System.Web.UI.Page
    { 
        public static int Login_ID { get; set; }
        public static int AdminLogin_ID { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            Login.Login_ID = 0;
        }

        protected void log_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT UserID FROM Accounts WHERE Username = @username AND Pin = @Pin", conn);
                cmd.Parameters.AddWithValue("@username", txtName.Text.Trim());
                cmd.Parameters.AddWithValue("@Pin", txtPin.Text.Trim());

                conn.Open();
                object result = cmd.ExecuteScalar();
                conn.Close();

                if (result != null)
                {
                    Login_ID = (int)result;

                    Response.Redirect("Details.aspx");
                }
                else
                {
                    string errorMessage = "Incorrect Username Or Pin";
                    lblErrorMessage.Text = errorMessage;
                    lblErrorMessage.Visible = true;
                }
            }
        }
        protected void log_Click2(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT UserID FROM ADMINS WHERE Username = @username AND Pin = @Pin", conn);
                cmd.Parameters.AddWithValue("@username", name.Text.Trim());
                cmd.Parameters.AddWithValue("@Pin", pass.Text.Trim());

                conn.Open();
                object result = cmd.ExecuteScalar();
                conn.Close();

                if (result != null)
                {
                    AdminLogin_ID = (int)result;

                    Response.Redirect("AdminWelcome.aspx");
                }
                else
                {
                    string errorMessage = "Incorrect Username Or Pin";
                    lblErrorMessage2.Text = errorMessage;
                    lblErrorMessage2.Visible = true;
                }
            }
        }
    }
}

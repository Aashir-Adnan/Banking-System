﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;
using System.Collections.Specialized;

namespace DBProj
{
    public partial class AdminSignUp : System.Web.UI.Page
    {
        private const int PageSize = 10;
        private int CurrentPage = 1;
        private int PageCount = 1;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT Count(*) FROM SignUp", con);
                con.Open();
                PageCount = (int)Math.Ceiling(Convert.ToDouble(cmd.ExecuteScalar()) / PageSize);
                con.Close();
            }


        }
        private void BindGrid()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT RequestID, FullName, CNIC, Username, Pin, AccountType FROM Signup ORDER BY RequestID ASC OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY", con);
                cmd.Parameters.AddWithValue("@Offset", (CurrentPage - 1) * PageSize);
                cmd.Parameters.AddWithValue("@PageSize", PageSize);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                GridView1.DataSource = null;
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Approve")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument); // Get the index of the row where the button was clicked
                GridViewRow firstRow = GridView1.Rows[rowIndex];
                TableCell firstCell = firstRow.Cells[0];
                int reqid = Convert.ToInt32(firstCell.Text);
                try
                {
                    if (rowIndex >= 0 && rowIndex < GridView1.Rows.Count)
                    {
                        string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            SqlCommand cmd = new SqlCommand("UPDATE SignUp SET ReqStatus = 1 WHERE RequestID = @reqid", conn);
                            cmd.Parameters.AddWithValue("@reqid", reqid);
                            conn.Open();
                            cmd.ExecuteNonQuery();
                            conn.Close();
                        }
                        lblErrorMessage.Text = "Sign Up Approved";
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = System.Drawing.Color.Green;
                        BindGrid();
                    }
                    else
                    {
                        // Handle invalid rowIndex (e.g., log error, display message to user)
                    }
                }
                catch (Exception ex)
                {
                    lblErrorMessage.Text = "An error occurred: " + ex.Message + " Index: " + rowIndex;
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = System.Drawing.Color.Red;

                }


            }
        }

        protected void btnPrev_Click(object sender, EventArgs e)
        {
            CurrentPage--;
            if (CurrentPage < 1)
                CurrentPage = 1;
            BindGrid();

        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            if (CurrentPage < PageCount)
                CurrentPage++;
            BindGrid();
        }
    }
}
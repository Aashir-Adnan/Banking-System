﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;
using System.Collections.Specialized;
using System.Drawing;

namespace DBProj
{
    public partial class AdminWelcome : System.Web.UI.Page
    {
        private const int PageSize = 10;
        private int CurrentPage = 1;
        private int PageCount = 1;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT Count(*) FROM Accounts", con);
                con.Open();
                PageCount = (int) Math.Ceiling(Convert.ToDouble (cmd.ExecuteScalar()) / PageSize);
                con.Close(); 
            }


        }

        private void BindGrid()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT UserID, FullName FROM Accounts ORDER BY UserID ASC OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY", con);
                cmd.Parameters.AddWithValue("@Offset", (CurrentPage - 1) * PageSize);
                cmd.Parameters.AddWithValue("@PageSize", PageSize);
                GridView1.PageSize = 10;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                GridView1.DataSource = null;
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        private void FullGrid(int userid)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT UserID, FullName, CNIC, Balance, AccountType, AccountStatus, Heirs FROM Accounts WHERE UserID = @UserID", conn);
                cmd.Parameters.AddWithValue("@UserID", userid);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                GridView2.DataSource = dt;
                GridView2.DataBind();
                reader.Close();

                SqlCommand cmd2 = new SqlCommand("SELECT CardID, CardType, CreditLimit FROM Cards WHERE UserID = @UserID", conn);
                cmd2.Parameters.AddWithValue("@UserID", userid);
                SqlDataReader reader1 = cmd2.ExecuteReader();
                DataTable dt1 = new DataTable();
                dt1.Load(reader1);
                GridView3.DataSource = dt1;
                GridView3.DataBind();
                reader1.Close();

                SqlCommand cmd3 = new SqlCommand("SELECT BillID, Date, TransactionAmount, ReceiverID FROM Bills WHERE UserID = @UserID", conn);
                cmd3.Parameters.AddWithValue("@UserID", userid);
                SqlDataReader reader2 = cmd3.ExecuteReader();
                DataTable dt2 = new DataTable();
                dt2.Load(reader2);
                GridView4.DataSource = dt2;
                GridView4.DataBind();
                reader2.Close();
            }
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "SeeMore")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                GridViewRow firstRow = GridView1.Rows[rowIndex];
                TableCell firstCell = firstRow.Cells[0];
                int userid = Convert.ToInt32(firstCell.Text);
                try
                {
                    if (rowIndex >= 0 && rowIndex < GridView1.Rows.Count)
                    {
                        DataTable dt4 = new DataTable();
                        GridView1.DataSource = dt4;
                        GridView1.DataBind();

                       FullGrid(userid);
                    }
                }
                catch (Exception ex)
                {
                    lblErrorMessage.Text = "An error occurred: " + ex.Message + " Index: " + rowIndex;
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = System.Drawing.Color.Red;

                }
            }
            else if (e.CommandName == "Freeze")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument); 
                GridViewRow firstRow = GridView1.Rows[rowIndex];
                TableCell firstCell = firstRow.Cells[0];
                int userid = Convert.ToInt32(firstCell.Text);
                try
                {
                    if (rowIndex >= 0 && rowIndex < GridView1.Rows.Count)
                    {
                        DataTable dt4 = new DataTable();
                        GridView1.DataSource = dt4;
                        GridView1.DataBind();

                        string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            SqlCommand cmd = new SqlCommand("UPDATE Accounts SET AccountStatus = 0 WHERE UserID = @UserID", conn);
                            cmd.Parameters.AddWithValue("@UserID", userid);
                            conn.Open();
                            cmd.ExecuteNonQuery();

                            FullGrid(userid);


                        }
                    }
                }
                catch (Exception ex)
                {
                    lblErrorMessage.Text = "An error occurred: " + ex.Message + " Index: " + rowIndex;
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = System.Drawing.Color.Red;

                }


            }
            else if (e.CommandName == "Unfreeze")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                GridViewRow firstRow = GridView1.Rows[rowIndex];
                TableCell firstCell = firstRow.Cells[0];
                int userid = Convert.ToInt32(firstCell.Text);
                try
                {
                    if (rowIndex >= 0 && rowIndex < GridView1.Rows.Count)
                    {
                        DataTable dt4 = new DataTable();
                        GridView1.DataSource = dt4;
                        GridView1.DataBind();

                        string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            SqlCommand cmd = new SqlCommand("UPDATE Accounts SET AccountStatus = 1 WHERE UserID = @UserID", conn);
                            cmd.Parameters.AddWithValue("@UserID", userid);
                            conn.Open();
                            cmd.ExecuteNonQuery();

                            FullGrid(userid);


                        }

                    }
                                    }
                catch (Exception ex)
                {
                    lblErrorMessage.Text = "An error occurred: " + ex.Message + " Index: " + rowIndex;
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = System.Drawing.Color.Red;

                }


            }
        }

        protected void btnPrev_Click(object sender, EventArgs e)
        {
            CurrentPage--;
            if (CurrentPage < 1)
                CurrentPage = 1;
            DataTable dt4 = new DataTable();
            GridView2.DataSource = dt4;
            GridView2.DataBind();
            GridView3.DataSource = dt4;
            GridView3.DataBind();
            GridView4.DataSource = dt4;
            GridView4.DataBind();
            BindGrid();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            if (CurrentPage < PageCount)
                CurrentPage++;
            DataTable dt4 = new DataTable();
            GridView2.DataSource = dt4;
            GridView2.DataBind();
            GridView3.DataSource = dt4;
            GridView3.DataBind();
            GridView4.DataSource = dt4;
            GridView4.DataBind();
            BindGrid();
        }
    }
}
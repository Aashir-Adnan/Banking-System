﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;

namespace DBProj
{
    public partial class Withdrawal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void log_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT UserID FROM Accounts WHERE UserID = @UserID AND Pin = @Pin", conn);
                cmd.Parameters.AddWithValue("@UserID", Login.Login_ID);
                cmd.Parameters.AddWithValue("@Pin", pass.Text.Trim());

                conn.Open();
                object result = cmd.ExecuteScalar();
                conn.Close();

                if (result != null)
                {


                    SqlCommand cmd2 = new SqlCommand("EXEC WITHDRAWAL @Amount = @amm, @UserID = @UID", conn);
                    cmd2.Parameters.AddWithValue("@UID", Login.Login_ID);

                    int withdrawalAmmount = 0;
                    if (int.TryParse(withAm.Text, out withdrawalAmmount))
                    {
                        cmd2.Parameters.AddWithValue("@amm", withdrawalAmmount);
                        
                        conn.Open();
                        cmd2.ExecuteNonQuery();
                        conn.Close();

                        string errorMessage = "Withdrawal Successful";
                        lblErrorMessage.Text = errorMessage;
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = System.Drawing.Color.Green;
                    }
                    else
                    {
                        lblErrorMessage.Text = "Please enter a valid integer for the deposit amount.";
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                        Response.Redirect("Withdrawal.aspx");

                    }

                }
                else
                {
                    string errorMessage = "Incorrect Pin";
                    lblErrorMessage.Text = errorMessage;
                    lblErrorMessage.Visible = true;
                    Response.Redirect("Withdrawal.aspx");

                }
            }
        }
    }
}
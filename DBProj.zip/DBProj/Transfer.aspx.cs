﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;

namespace DBProj
{
    public partial class Transfer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        protected void logout(object sender, EventArgs e)
        {
            Login.Login_ID = 0;
            Response.Redirect("Login.aspx");
        }

        protected void log_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT UserID FROM Accounts WHERE UserID = @UserID AND Pin = @Pin", conn);
                cmd.Parameters.AddWithValue("@UserID", Login.Login_ID);
                cmd.Parameters.AddWithValue("@Pin", pass.Text.Trim());

                conn.Open();
                object result = cmd.ExecuteScalar();
                conn.Close();

                if (result != null)
                {


                    SqlCommand cmd2 = new SqlCommand("InsertIntoTransactions", conn);

                    try
                    {
                        int transferAmount = 0;
                        int transferID = 0;
                        if (int.TryParse(tranAm.Text, out transferAmount) && int.TryParse(tranID.Text, out transferID))
                        {
                            cmd2.CommandType = CommandType.StoredProcedure; // Set the command type to Stored Procedure
                            cmd2.Parameters.AddWithValue("@SenderID", Login.Login_ID);
                            cmd2.Parameters.AddWithValue("@ReceiverID", transferID); // Assuming transferID is the receiver ID
                            cmd2.Parameters.AddWithValue("@Amount", transferAmount);

                            // Define an output parameter to capture the VARCHAR(140) value returned by the stored procedure
                            SqlParameter outputParam = new SqlParameter("@output", SqlDbType.VarChar, 100);
                            outputParam.Direction = ParameterDirection.Output;
                            cmd2.Parameters.Add(outputParam);
                            // Execute the stored procedure
                            conn.Open();
                            cmd2.ExecuteNonQuery();

                            // Retrieve the output parameter value as a string
                            string outputMessage = cmd2.Parameters["@output"].Value.ToString();
                            conn.Close();

                            // Use the outputMessage string as needed in your code

                            lblErrorMessage.Text = outputMessage;
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = System.Drawing.Color.Green;
                        }
                        else
                        {
                            lblErrorMessage.Text = "Please enter valid integers for the transfer amount and ID.";
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                        }
                    }
                    catch (Exception ex)
                    {
                        lblErrorMessage.Text = "An error occurred: " + ex.Message;
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                    }

                }
                else
                {
                    string errorMessage = "Incorrect Pin";
                    lblErrorMessage.Text = errorMessage;
                    lblErrorMessage.Visible = true;
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;

namespace DBProj
{
    public partial class Heir : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        protected void logout(object sender, EventArgs e)
        {
            Login.Login_ID = 0;
            Response.Redirect("Login.aspx");
        }

        protected void log_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myConnectionstring"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                    SqlCommand cmd2 = new SqlCommand("InsertIntoHeirs", conn);

                    try
                    {
                            cmd2.CommandType = CommandType.StoredProcedure; 
                            cmd2.Parameters.AddWithValue("@UserID", Login.Login_ID);
                            cmd2.Parameters.AddWithValue("@Relation",relation.Text.Trim());
                            cmd2.Parameters.AddWithValue("@HeirName", name.Text.Trim());
                            cmd2.Parameters.AddWithValue("@HeirCNIC", CNIC.Text.Trim());

                            SqlParameter outputParam = new SqlParameter("@output", SqlDbType.VarChar, 140);
                            outputParam.Direction = ParameterDirection.Output;
                            cmd2.Parameters.Add(outputParam);
                            conn.Open();
                            cmd2.ExecuteNonQuery();

                            string outputMessage = cmd2.Parameters["@output"].Value.ToString();
                            conn.Close();


                            lblErrorMessage.Text = outputMessage;
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = System.Drawing.Color.Green;
                    }
                    catch (Exception ex)
                    {
                        lblErrorMessage.Text = "An error occurred: " + ex.Message;
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                    }
            }
        }
    }
}
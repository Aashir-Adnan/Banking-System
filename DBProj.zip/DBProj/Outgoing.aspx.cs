﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.Services.Description;
using static System.Net.Mime.MediaTypeNames;

namespace DBProj
{
    public partial class Outgoing : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Connection string from web.config
                string connectionString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("SELECT T.TransactionID, A.FullName, T.Amount, T.Date FROM Transactions T JOIN Accounts A ON T.ReceiverID = A.UserID WHERE SenderID = @UserID", conn);
                   

                    cmd.Parameters.AddWithValue("@UserID", Login.Login_ID);

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    GridView1.DataSource = reader;
                    GridView1.DataBind();

                    reader.Close();
                }
            }
        }
        protected void logout(object sender, EventArgs e)
        {
            Login.Login_ID = 0;
            Response.Redirect("Login.aspx");
        }

        protected void log_Click(object sender, EventArgs e)
        {
        }
    }
}